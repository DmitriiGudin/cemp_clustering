from __future__ import division
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import operator
import hdbscan
from astropy.stats import biweight_scale, biweight_location
import os
import params
from sklearn.preprocessing import RobustScaler


minimum_cluster_size = 3
minimum_samples = minimum_cluster_size
cluster_selection_epsilon = 0


def get_column(N, Type, filename):
    return np.genfromtxt(filename, delimiter=',', dtype=Type, skip_header=1, usecols=N, comments=None)


def clustering (e, jr, jphi, jz):
    data = np.array([[a,b,c,d] for a, b, c, d in zip(e, jr, jphi, jz)])
    clusterer = hdbscan.HDBSCAN(min_cluster_size=minimum_cluster_size, min_samples=minimum_samples, cluster_selection_epsilon=cluster_selection_epsilon, cluster_selection_method='leaf', prediction_data=True)
    clusterer.fit(data)
    groups = []
    N_groups = clusterer.labels_.max()
    for i in range(N_groups+1):
        groups.append(list(np.where(clusterer.labels_==i)[0]))
    return groups


if __name__ == '__main__':
    init_file = params.init_file
    kin_file = params.kin_file

    CFe = get_column(9, str, params.init_file)[:]
    
    E = get_column(21, float, params.kin_file)[:]
    J_r = get_column(11, float, params.kin_file)[:]
    J_phi = get_column(13, float, params.kin_file)[:]
    J_z = get_column(19, float, params.kin_file)[:]

    e = (E - biweight_location(E))/biweight_scale(E)
    jr = (J_r - biweight_location(J_r))/biweight_scale(J_r)
    jphi = (J_phi - biweight_location(J_phi))/biweight_scale(J_phi)
    jz = (J_z - biweight_location(J_z))/biweight_scale(J_z)

    clusters = clustering (e, jr, jphi, jz)
    cut_clusters = [c for c in clusters if len(c)>2]

    # Reorder clusters.
    lengths = np.array([len(c) for c in clusters])
    indices = (-lengths).argsort()
    clusters = [clusters[i] for i in indices]
    
    lengths = np.array([len(c) for c in cut_clusters])
    indices = (-lengths).argsort()
    cut_clusters = [cut_clusters[i] for i in indices]

    for k in range(len(clusters)):
        for i in range(len(clusters)-1):
            if len(clusters[i+1])==len(clusters[i]) and min(CFe[clusters[i+1]])<min(CFe[clusters[i]]):
                clusters[i], clusters[i+1] = clusters[i+1], clusters[i]

    for k in range(len(cut_clusters)):
        for i in range(len(cut_clusters)-1):
            if len(cut_clusters[i+1])==len(cut_clusters[i]) and min(CFe[cut_clusters[i+1]])<min(CFe[cut_clusters[i]]):
                cut_clusters[i], cut_clusters[i+1] = cut_clusters[i+1], cut_clusters[i]

    for i in range(len(clusters)):
        CFes = np.array([CFe[j] for j in clusters[i]])
        indices = CFes.argsort()
        clusters[i] = [clusters[i][j] for j in indices]

    for i in range(len(cut_clusters)):
        CFes = np.array([CFe[j] for j in cut_clusters[i]])
        indices = CFes.argsort()
        cut_clusters[i] = [cut_clusters[i][j] for j in indices]

    # Save clusters into a file.

    if os.path.isfile(params.clusters_file):
        os.remove(params.clusters_file)
    with open(params.clusters_file,'w') as clusters_file:
        clusters_file.write("from __future__ import division\n")
        clusters_file.write("import numpy as np\n")
        clusters_file.write("\n")
        clusters_file.write("\n")
        clusters_file.write("all_clusters = " + str(list(clusters)) + "\n")
        clusters_file.write("\n")
        clusters_file.write("final_clusters = " + str(list(cut_clusters)) + "\n")

    print "Clusters: " + str(list(cut_clusters))
    print "Number of clusters: " + str(len(cut_clusters))

